import React, { useState } from 'react';

const EventData = (porps) => {
  // Assume you have loaded JSON data from an API or a file
  

  // Render the JSON data on the UI with checkboxes
  return (
    <div>
      <h1>Event Data</h1>
      <div>

      </div>
    </div>
  );
};

export default EventData;
