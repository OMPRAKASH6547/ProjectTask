import React, { useState } from 'react';
import { format, addWeeks, subWeeks } from 'date-fns';
import { MdNavigateNext } from "react-icons/md";
import { FcPrevious } from "react-icons/fc";
import EventData from './EventData';


const Calendar = () => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [selectedTimeZone, setSelectedTimeZone] = useState('UTC-0');

    const [selectedValues, setSelectedValues] = useState([]);

    const Day = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
    const WorkingDay = ['8:00 AM', '8:30 AM', '9:00 AM', '9:30 AM', '10:00 AM', '10:30 AM',
        '11:00 AM', '11:30 AM', '12:00 PM', '12:30 PM', '1:00 PM', '1:30 PM', '2:00 PM', '2:30 PM',
        '3:00 PM', '3:30 PM', '4:00 AM', '4:30 PM', '5:00 PM', '5:30 PM', '6:00 PM', '6:30 PM',
        '7:00 PM', '7:30 PM', '8:00 AM', '8:30 PM', '9:00 PM', '9:30 PM', '10:00 PM', '10:30 PM',
        '11:00 PM'
    ]
    console.log(currentDate);
    const handlePrevWeek = () => {
        setCurrentDate(subWeeks(currentDate, 1));
    };

    const handleNextWeek = () => {
        setCurrentDate(addWeeks(currentDate, 1));
    };

    const handleTimeZoneChange = (event) => {
        const newTimeZone = event.target.value;
        setSelectedTimeZone(newTimeZone);
    };


    const handleCheckboxChange = (value) => {
        // Check if the value is already in the array
        const isChecked = selectedValues.includes(value);

        // If it's checked, remove it; otherwise, add it
        const updatedValues = isChecked
            ? selectedValues.filter((item) => item !== value)
            : [...selectedValues, value];

        // Update the state with the new array of selected values
        setSelectedValues(updatedValues);
    };

    console.log(selectedValues)



    // Render the calendar UI

    return (
        <div style={{ fontFamily: 'Arial, sans-serif', textAlign: 'center' }}>
            {/* <h1 style={{ marginBottom: '20px' }}>Calendar</h1> */}
            <div style={{ backgroundColor: "blue", display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: '10px' }}>
                <button
                    style={{ marginRight: '10px', padding: '5px 10px', cursor: 'pointer' }}
                    onClick={handlePrevWeek}
                >
                    <FcPrevious />Previous Week
                </button>
                <div style={{ marginBottom: '20px', color: "white" }}>
                    <strong >Current Date:</strong>{' '}
                    {format(currentDate, 'MMMM d, yyyy', { timeZone: selectedTimeZone })}
                </div>
                <button
                    style={{ padding: '5px 10px', cursor: 'pointer' }}
                    onClick={handleNextWeek}
                >
                    Next Week<MdNavigateNext />
                </button>
            </div>

            <div style={{ backgroundColor: "aqua", display: "flex", padding: "3vh", top: "0", marginBottom: '10px' }}>
                <label style={{ marginRight: '1vw' }}>Select Timezone:</label>
                <select
                    onChange={handleTimeZoneChange}
                    value={selectedTimeZone}
                    style={{ padding: '5px', cursor: 'pointer' }}
                >
                    <option value="UTC-0">UTC-0</option>
                    <option value="Another Timezone">UTC-11</option>
                </select>

            </div>

            <div style={{ display: "flex" }}>
                <div style={{ display: "flex", flexDirection: "column", left: "0px", background: "yellow", height: "80vh", width: "10vw", justifyContent: 'space-between' }}>

                    {
                        Day.map(day => {
                            return (<>
                                <div>
                                    {day}
                                    <div style={{ marginBottom: '20px', color: "black" }}>
                                        {format(currentDate, 'MMMM / d', { timeZone: selectedTimeZone })}
                                    </div>

                                </div>
                            </>)


                        })
                    }



                </div>
                <div style={{ height: "80vh", width: "90vw", backgroundColor: "red", display: "flex ", justifyContent: 'space-between', flexDirection: "column", }}>

                    <div style={{ backgroundColor: "pink", display: "flex", flexFlow: "wrap", padding: "3vh", gap: "2vh" }} ><p>Past</p></div>
                    <div style={{ backgroundColor: "pink", display: "flex", flexFlow: "wrap", padding: "3vh", gap: "2vh" }}><p>Past</p></div>
                    <div style={{ backgroundColor: "pink", display: "flex", flexFlow: "wrap", padding: "3vh", gap: "2vh" }}>
                        {

                            WorkingDay.map(time => {
                                return (
                                    <>
                                        <div>
                                            <input type='checkbox'
                                                value={time}
                                                checked={selectedValues.includes({ time })}
                                                onChange={(e) => {
                                                    e.preventDefault()
                                                    handleCheckboxChange({ time })
                                                }}
                                            />
                                            {time}
                                        </div>
                                    </>
                                )
                            })
                        }
                    </div>

                    <div style={{ backgroundColor: "pink", display: "flex", flexFlow: "wrap", gap: "2vh" }}>
                        {

                            WorkingDay.map(time => {
                                return (
                                    <>
                                        <div>
                                            <input type='checkbox' />
                                            {time}
                                        </div>
                                    </>
                                )
                            })
                        }
                    </div>
                    <div style={{ backgroundColor: "pink", display: "flex", flexFlow: "wrap", padding: "3vh", gap: "2vh" }}>
                        {

                            WorkingDay.map(time => {
                                return (
                                    <>
                                        <div>
                                            <input type='checkbox' />
                                            {time}
                                        </div>
                                    </>
                                )
                            })
                        }
                    </div>

                </div>
            </div>
            <div>


            </div>

        </div>
    );
};

export default Calendar;
