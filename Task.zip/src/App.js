
import './App.css';
import Calendar from './components/Calendar';
import EventData from './components/EventData';
import NewCalendar from './components/NewCalendr';
function App() {
  return (
    <div>
      <Calendar />
      {/* <EventData /> */}

      {/* <NewCalendar/> */}
    </div>
  );
}

export default App;
